package hash;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class QuadInsertTest {

	@Test
	void testQuadProbing() {
		DataItem[] array = new DataItem[5];
		array[0] = new DataItem(4);
		
		int nextHashValue = HashTable.quadProbing(array,  5,  0);
		
		
		assertEquals(1, nextHashValue);
	}

}
